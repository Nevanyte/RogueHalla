# Faction farming benchmark archive

All `raw/*.jsonl` entries are offline 40 Hz authoritative benchmark snapshots, not live room data. They retain the bench seed, public map identity, focal inventory, alive/reached flags, normal clear count, movement, and actual paid focus-toast count. Terminal result rows and snapshot state hashes are excluded. `evaluations/*.json` are deterministic summaries from the repository evaluators.

## Cohorts and source

- `normal-origin-{route,nearest}-261-310`: predeclared 50-map exploratory product prototype, ten maps per faction and five per authored build, `ThemedFocus` opt-in, focal RaidBot against seven unchanged fill RaidBots. Trial binary SHA-256 `efbcd5e92760381ef497246dde3061a33146a65c6284acabb38a463e931036f8`, built during preparation of `ab9979970`. A full seed-251 replay with the final `ab9979970` source-matched binary reproduced every parsed checkpoint exactly; only terminal hash encoding changed with the optional-arm layout fix.
- `{focus-route,focus-risk,focus-live,theme-stat,theme-risk}-311-320`: ten fresh equal-risk control maps, one per authored build. `focus-*` uses optional `ThemedFocus`; `theme-*` uses ordinary `Themed` payouts. Final source `ab9979970`, binary SHA-256 `1d7fcdd83fcfca8da281556384b2d2e6b7ac31c40f40f733765f91ff820f3ec4`.
- `{live,post-five-target,post-five-nearest}-321-330`: declared ten-map fit, one per build. `{live,post-five-target,post-five-nearest}-331-350`: untouched 20-map holdout, two per build. All use ordinary `Themed` payouts and stock decisions through active minute five. Isolated LAB source is `ab9979970` plus `source/post-five-lab.patch` (runtime commit `2e61e02cc`, archive-evaluator commit `83d3636ee`); trials used binary SHA-256 `866d6aa709cefa4542967d57c378f217f5557e187ca265b5e8fa9a4797a5b497`. Rebuilt committed source binary SHA-256 `24a8523443892114e6378fb699013634606b534187ad6da58f2a0b3ef4caf378` reproduced all four seed-321 snapshots and terminal result exactly. The frozen trial binary and source-commit rebuild differ only by rustfmt and a logically identical `if` collapse. The LAB patch was not applied to shipping runtime.
- Mirrored earned-kit combat used frozen `camp_bench` SHA-256 `46033d3b9dbc34fb044b24071c8f6c026d6809e9e8241134f0cfd8b0ea89b812`, equal faction and weapon with both seat orientations. Only both-alive pairs enter duels.

## Reproduce evaluations

From the repository root after extracting this archive to `FARM_ARCHIVE`:

```sh
python3 tools/balance-lab/route_tuning_eval.py FARM_ARCHIVE/raw/normal-origin-route-261-310.jsonl FARM_ARCHIVE/raw/normal-origin-nearest-261-310.jsonl /tmp/normal-origin-eval.json --duel target/release/camp_bench
python3 tools/balance-lab/route_tuning_eval.py FARM_ARCHIVE/raw/focus-route-311-320.jsonl FARM_ARCHIVE/raw/focus-risk-311-320.jsonl /tmp/focus-risk-eval.json
python3 tools/balance-lab/route_tuning_eval.py FARM_ARCHIVE/raw/theme-stat-311-320.jsonl FARM_ARCHIVE/raw/theme-risk-311-320.jsonl /tmp/theme-risk-eval.json
python3 tools/balance-lab/post_five_eval.py FARM_ARCHIVE/raw/post-five-target-331-350.jsonl FARM_ARCHIVE/raw/live-331-350.jsonl /tmp/post-five-incremental.json
python3 tools/balance-lab/route_tuning_eval.py FARM_ARCHIVE/raw/post-five-target-331-350.jsonl FARM_ARCHIVE/raw/live-331-350.jsonl /tmp/post-five-duel.json --duel target/release/camp_bench
```

Build the duel executable from the benchmark source with `cargo build --release -p rh-headless --bin camp_bench`. The post-five LAB binary can be rebuilt in a disposable checkout of `ab9979970` by applying `source/post-five-lab.patch` and running `cargo build --release -p rh-headless --features strategy-route-lab --bin strategy_route_lab`. `post_five_eval.py` verifies every paired minute-five state hash in the unsanitized run before it produces a summary; the archived rows omit those values, so archive re-evaluation checks matching public identity and inventory rather than the private hash. The complete pre-publication minute-five hash check passed for all 30 fit and holdout seeds.
